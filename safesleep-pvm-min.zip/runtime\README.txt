SafeSleepPVM Windows x64 SDK

CPython version: 3.16.0a2+dev

This runtime was built from CPython commit 5982947.

Run Python with:
  safesleep-python.cmd path\to\script.py

SafeSleepPVM adds:
  sys.set_max_sleep_sec(seconds)
  sys.get_max_sleep_sec()

A positive limit caps longer time.sleep() calls. Zero and negative values
disable the limit. The limit is disabled by default.
